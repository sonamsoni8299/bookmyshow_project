﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookMyShow_DAO
{
    public class Reschedule
    {
        public int RescheduleId { get; set; }
        public int BookingId { get; set; }
        public string? BookingTime { get; set; }
    }
}
